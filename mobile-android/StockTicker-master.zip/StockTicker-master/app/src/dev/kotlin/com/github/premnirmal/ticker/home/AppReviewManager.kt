package com.github.premnirmal.ticker.home

import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext

class AppReviewManager(@ApplicationContext context: Context) : IAppReviewManager