package com.github.premnirmal.ticker.components

import timber.log.Timber

/**
 * Created by premnirmal on 2/28/16.
 */
internal class LoggingTree : Timber.DebugTree()