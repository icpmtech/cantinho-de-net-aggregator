package com.github.premnirmal.ticker.home

import android.os.Bundle

interface ChildFragment {
  fun setData(bundle: Bundle) {}
  fun scrollToTop() {}
}