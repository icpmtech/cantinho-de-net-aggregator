package com.github.premnirmal.ticker.home

import android.app.Activity

interface IAppReviewManager {
  fun launchReviewFlow(activity: Activity) {}
}